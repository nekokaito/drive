#include <stdio.h>

int mymod(int b, int p, int m);
int main ()
{
    int s , n , f;
    while (scanf("%d %d %d", &s, &n, &f) != EOF)

    printf("%d\n", mymod(s,n,f));

    return 0;
}
int mymod(int b, int p, int m)
{ int x=0, y=0;
    if(p == 0) {
            return 1;
    }
    else if(p%2 == 1)
    {
        x = b%m;
        y = (mymod(b, p-1, m))%m;
        return (x*y)%m;
    }
    else if(p%2 == 0)
    {
        y = (mymod(b, p/2, m))%m;
        return (y*y)%m;
    }
}

