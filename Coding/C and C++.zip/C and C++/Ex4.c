#include <stdio.h>

int main () {

int i, n, sum;
scanf("%d", &i);
scanf("%d", &n);

 for (i; i<=n; i++) {


        printf ("%d ", i);

        sum = sum+i;

 }

 printf ("\n%d ",sum);


  return 0;
}



