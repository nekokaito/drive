#include <stdio.h>

int mymod(int b, int p, int m)
{ int x=0, y=0, z=0, result=0;
    if(p == 0) {
        result= 1;
            printf ("%d", result);
    }
    else if(p % 2 == 1)
    {
        x = b%m;
        y = (mymod(b , p-1 , m))%m;
     result = (x*y)%m;
       printf ("%d", result);
    }
    else if(p % 2 == 0)
    {
        y = (mymod(b , p/2 , m))%m;
        result = (y*y)%m;
        printf ("%d", result);
    }
}

int main ()
{
    int b , p , m;
    scanf("%d %d %d", &b, &p, &m);

    mymod(b,p,m);

    return 0;
}

