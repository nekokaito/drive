#include <stdio.h>

int main ()

{
    double y, sum;
    int x ;

    y= 50.57;
    x = 90;
    sum = y + x;

    printf ("%lf", sum);


    return 0;

}
