#include <iostream>
#include <string>
using namespace std;
int main() {

   int n;
   int size;
   cin>>n;
   string s;


  for (int i=0; i<n ; i++) {
    cin >>s;
    size = s.length();
    if (size>10) {
        cout<<s[0]<<size-2<<s[size-1]<<endl;
    }
    else {
        cout<<s<<endl;
    }
  }

  return 0;
}


