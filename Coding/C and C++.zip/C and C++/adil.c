#include<stdio.h>

int main()
{
    int a, b, c;

    printf("Enter two integers:");
    scanf("%d %d", &a, &b);

    c = a + b;
    printf("value of c is: %d",c);

    c = a - b;
    printf("\nvalue of c is: %d",c);

    c = a * b;
    printf("\nvalue of c is: %d",c);

    c = a / b;
    printf("\nvalue of c is: %d",c);

    c = a % b;
    printf("\nvalue of c is: %d",c);

    return 0;
}
