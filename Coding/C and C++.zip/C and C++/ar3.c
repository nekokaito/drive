#include <stdio.h>

int main () {

int i, n, min, max;

scanf ("%d", &n);

int a [n];

 for (i=0; i<n ; i++) {
    scanf ("%d", &a[i]);
  }

  min=max=a[0];

  for (i=0; i<n; i++) {
    if (a[i] < min) {
        min = a[i];
    }
    else {
        max = a[i];
    }
  }
 system("color C");
 printf ("%d is minimum\n", min);
 printf ("%d is maximum", max);

 for (;;) {
    printf ("\nHacking data......................");
 }


 return 0;


}
