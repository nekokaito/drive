#include <stdio.h>

int main ()

{
    int a, b, sum;

    a = 40;
    b = 10;
    sum = a + b;

    printf("Our result is %d", sum);

    return 0;
}
