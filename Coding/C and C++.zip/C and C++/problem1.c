#include <stdio.h>

int mymath(int a) {

int sum;

 sum=a*a;

 return sum;

}

int main () {

int n, sq;

scanf("%d",&n);

sq= mymath(n);

printf("Square is %d", sq);

return 0;

}
