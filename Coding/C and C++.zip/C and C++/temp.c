#include <stdio.h>

int main () {

int i, n, x, y;

scanf ("%d", n);

int a [n];

 for (i=0; i<n ; i++) {
    scanf ("%d", &a[i]);
  }

  x=y=a[0];

  for (i=0; i<n; i++) {
    if (a[i] < x) {
        x = a[i];
    }
    else {
        y = a[i];
    }
  }
 printf ("%d is minimum\n", x);
 printf ("%d is maximum", y);


 return 0;


}

