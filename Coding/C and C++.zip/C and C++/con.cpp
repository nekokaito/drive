#include <iostream>
#include <string>
using namespace std;
int main() {

int a, b;
cin>>a>>b;
int count=0;
int ar[a];

for (int i =0; i<a ; i++)
 {
     cin>>ar[i];

    int con=ar[b-1];
    if(ar[i]>=con && ar[i]>0){
            count++;
        }
    }
    cout<<count;

}
