#include <stdio.h>

int main ()

 { int n=6;

     do {

        printf ("%d\n", n);

        n = n+1;
     }

     while (n<=5);

        return 0;




 }
