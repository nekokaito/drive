#include <stdio.h>

int mysum (int a) {


  if (a%2 == 0){
      printf ("Even");
   }

   else{
      printf ("Odd");
   }
}

int main ()
{
    int n;
    scanf ("%d", &n);

    mysum(n);

    return 0;
}
