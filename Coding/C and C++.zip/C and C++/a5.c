#include <stdio.h>

int main ()

{
    int n, max=0, max2=0;

    scanf ("%d", &n);

    int a[n];

  for (int i=0; i<n ; i++) {
    scanf ("%d", &a[i]);
  }

  for(int i=0; i<n; i++)  {

        if (a[i]>max) {
            max2=max;
            max=a[i];
        }

    else if (a[i]>max2 && a[i<max]) {
        max2 = a[i];
    }
  }

  printf ("Second largest number is %d", max2);

  return 0;
}
