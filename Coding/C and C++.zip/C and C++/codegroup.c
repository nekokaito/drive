#include<stdio.h>
int main()
{
    float a,b,x,s,m,d;
    printf("enter a value\n");
    scanf("%f", &a);

    printf("enter a second value\n");
    scanf("%f", &b);

    printf("\nif the numbers are a and b then\n");

    x=a+b;
      printf("the addition of a and b is %0.2f \n", x);

    s=a-b;
      printf("the subtraction of a and b is %0.2f\n", s);

    m=a*b;
      printf("the multiplication of a and b is %0.2f\n", m);

    d=a/b;
      printf("the division of a and b is %0.2f\n", d);


    return 0;

}
