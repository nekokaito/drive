#include<stdio.h>
int main ()
{  //Kaito's Code

    long long n, sum1, sum2, left, right, result;
    scanf ("%lld", &n);

    int a[n];
    for(int i=0; i<n; i++) {
        scanf ("%d", &a[i]);
    }

    sum1=0;
    sum2=0;
    left=0;
    right=n-1;

    while (left<=right) {
        if (sum1<sum2) {
                sum1= sum1+a[left];
            left++;

        }
        else {
            sum2=sum2+a[right];
            right--;
        }

        if (sum1==sum2) {
            result=sum1;
        }
        if (sum1==!sum2)  {
        result = 0;
    }

    }

    printf ("%lld", result);

  return 0;
}
