#include<stdio.h>

int main()
{
    int a,b,c;

    printf("Enter three number: ");
    scanf("%d%d%d", &a, &b, &c);


        if (a>=b)

        printf("%d is the largest number.",a);


         printf("%d is the largest number.",c);
    }
    else {
    if (b>=c)

        printf("ad is the largest number.",b);

    else
        printf("%d is the largest number.",c);

}
}

