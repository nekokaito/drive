#include <stdio.h>

void main ()

{
    //This is my Univercity's First Program

    printf ("My Name is Siddiq");

    getch();
}
