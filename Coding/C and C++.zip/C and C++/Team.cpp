#include <iostream>
#include <string>
using namespace std;
int main() {

   int n;
   cin>>n;
   int a[3];
   int sum = 0;
   int maincount = 0;
  for (int i=1; i<=n ; i++) {
        int onecount=0;
     for(int j=0; j<3; j++) {
     cin>>a[j];

     if (a[j] == 1) {
        onecount++;
     }
     }
     if(onecount>=2) {
        maincount++;
     }
  }
  cout<<maincount;
return 0;
}



