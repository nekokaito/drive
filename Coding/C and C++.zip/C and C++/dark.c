#include <stdio.h>

int main()
{

    int a;

    scanf("%d",&a);


	printf("Hello World\n");
	printf ("The Input is: %d", a);
	return 0;
}
