#include<stdio.h>
int main()
{
 	int i, j, rows;
 	printf("Enter Half Diamond Rows =  ");
 	scanf("%d", &rows);

    printf("Half Diamond Star Pattern\n");
	for(i = 1; i <= rows; i++)
	{
        for(j = 1; j <= i; j++)
        {
             printf("*");
        }
        printf("\n");
    }

    for(i = rows - 1; i > 0; i--)
	{
        for(j = 1; j <= i; j++)
        {
             printf("*");
        }
        printf("\n");
    }
 	return 0;
}
