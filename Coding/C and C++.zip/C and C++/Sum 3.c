#include <stdio.h>

int main ()

{
    int a = 50, b = 20, sum = a - b;

    printf ("Our result is %d", sum);

    return 0;
}
