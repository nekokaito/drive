#include <stdio.h>

int main ()
{
    int b, p, m, x=0, y=0, z=0;
    scanf ("%d %d %d", b,p,m);

    if (p==0) {
        printf("1");
    }

    else if (p%2== 1) {
        x = b%m;

    }

}
