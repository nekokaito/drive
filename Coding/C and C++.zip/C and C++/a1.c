#include <stdio.h>

int main ()

{
   int a[1000];
   int i, n;

   scanf("%d", &n);


  for (i=0; i<n ; i++) {
    scanf("%d", &a[i]);


  printf("\nElements in array are: ");

  for (i=0; i<n ; i++) {
    printf("%d, ", a[i]);
  }

  return 0;

}
