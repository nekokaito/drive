#include <stdio.h>

int main () {

int i=0, j, n;

  scanf ("%d", &n);

  int a[1000];

  for (int s=0; s<n; s++) {
  	scanf ("%d", &a[i]);
  }

  while (i<n) {

     for (j=i+1; j<n; j++) {

     	if (a[i] == a[j]) {
     		printf ("%d\n", a[j]);
     	}
     }
     i++;
}

 return 0;

}
