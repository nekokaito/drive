#include <stdio.h>

int main()
{

printf("Name: Abubakar Siddiq Sazzad\nUniversity ID: 222010058\nEmail: siddiqsazzad001@gmail.com");

return 0;

}
