#include <stdio.h>

int main ()

{
    int n, neg=0, pos=0;

    scanf ("%d", &n);

  int a[100];

  for (int i=0; i<n ; i++) {
    scanf ("%d", &a[i]);
  }



  for (int i=0; i<n; i++) {
    if (a[i]<0) {
        neg++;

    }
    else {
        pos++;
    }
  }

  printf ("Total Negative Number is %d\n", neg);



  return 0;
}

