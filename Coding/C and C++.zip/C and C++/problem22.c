#include <stdio.h>

int swap(int a, int b) {

  int temp=0;

  temp=a;
  a=b;
  b=temp;

  printf ("After swap N1: %d and N2 %d", a, b);

}

int main () {

int n1, n2;

printf ("Input first number:");
scanf("%d",&n1);

printf ("Input 2nd number: ");
scanf("%d",&n2);

swap(n1,n2);


return 0;

}
