#include<stdio.h>
int main()
{
 printf("Enter your number: ");
 int a;
 scanf("%d", &a);
 for(int i=1; i<=a; i++)
 {
 if(i%2==0)
 {
 for(int k=1; k<=i; k++)
 {
 if(k%2==0)
 {
 printf("*");
 }
 else
 {
 printf(" ");
 }
 }
 }
 else
 {
 for(int k=1; k<=i; k++)
 {
 if(k%2!=0)
 {
 printf("*");
 }
 else
 {
 printf(" ");
 }
 }
 }
 printf("\n");
 }
 for(int i=a+a; i>a; i--)
 {
 if(i%2==0)
 {
 for(int k=1; k<=i-a; k++)
 {
 if(k%2==0)
 {
 printf("*");
 }
 else
 {
 printf(" ");
 }
 }
 }
 else
 {
 for(int k=1; k<=i-a; k++)
 {
 if(k%2!=0)
 {
 printf("*");
 }
 else
 {
 printf(" ");
 }
 }
 }
 printf("\n");
 }
 return 0;
}
