#include <stdio.h>

int main ()

{
    int n, odd=0, even=0;

    scanf ("%d", &n);

  int a[100];

  for (int i=0; i<n ; i++) {
    scanf ("%d", &a[i]);
  }



  for (int i=0; i<n; i++) {
    if (a[i]%2==0) {
        even++;

    }
    else {
        odd++;
    }
  }

  printf ("Total Even Number is %d\n", even);
  printf ("Total Odd Number is %d\n", odd);


  return 0;
}
