#include <stdio.h>

int main ()

{
    printf("Hello, My name is Kaito");
    printf("Well, I am learning coding");

    return 0;
}
