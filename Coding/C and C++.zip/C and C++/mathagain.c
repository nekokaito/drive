#include <stdio.h>

int main ()

{
    int a, b, sum;

    a = 4, b = 7, sum = a+b;

    printf ("%d+%d=%d", a,b,sum);
}
