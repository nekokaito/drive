#include <stdio.h>

int main ()

{
   int x[1000];
   int y [1000];
   int i, n;

   scanf("%d", &n);


  for (i=0; i<n ; i++) {
    scanf("%d", &x[i]);
  }

  for (i=0; i<n; i++) {
    y[i]=x[i];
  }

  printf ("x[%d] Input: ", n);
  for (i=0; i<n; i++) {
    printf ("%d, ", x[i]);
  }
  printf("\n");
  printf("Successfully copied to y[%d]\n", n);
  printf ("y[%d] Array Elements: ", n);
   for (i=0; i<n; i++) {
    printf ("%d, ", y[i]);
  }

  return 0;


}
