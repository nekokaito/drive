#include <stdio.h>

int main ()

{
    int x, y;

    x= 1;
    y= x;
    x= 2;

        printf ("Answer is %d", y);

        return 0;
}
