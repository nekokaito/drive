#include <iostream>
#include <string>
using namespace std;
int main() {

   int n;
   String s[1000];
   int size;
   cin>>n;



  for (int i=0; i<n ; i++) {
    cin>>s;
    size = s.length();
    if (size>10) {
        cout<<s[0]<<size-2<<s[size-1];
    }
    else {
        cout<<s;
    }
  }

  return 0;
}

