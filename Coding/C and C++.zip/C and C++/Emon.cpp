#include <iostream>
#include <string>
using namespace std;

class Vector {
protected:
  static string type;
public:
  virtual string getType() = 0;
  virtual double dot(Vector&) = 0;
  virtual double dot(Vector2D&) = 0;
};

string Vector::type = "Vector";

class Vector2D : public Vector {
private:
  double x;
  double y;
public:
  Vector2D(double x, double y) {
    this->x = x;
    this->y = y;
  }
  string getType() {
    return type;
  }
  double dot(Vector& v) {
    return v.dot(*this);
  }
  double dot(Vector2D& v) {
    return x*v.x + y*v.y;
  }
};

int main() {
  Vector2D v1(1.0, 2.0);
  Vector2D v2(3.0, 4.0);

  cout << v1.dot(v2) << endl; // Invokes dot(Vector2D&)
  cout << v2.dot(v1) << endl; // Invokes dot(Vector2D&)
  return 0;
}
